import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Htmlparser2014302580181 {

	
	public static void main(String[] args){
		// TODO �Զ����ɵķ������
		
		Document doc = null;
		try {
			doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cheng Si-Xue").get();
			
			String title = doc.title();		
			Element content = doc.getElementById("content"); 
			Elements mail = doc.select("[^/w+([-+.]/w+)]*@[/w+([-.]/w+)]*[/./w+([-.]/w+)*$]");
			Elements phonenumber = doc.select("[0,9]{7,13}");
		    for (Element ele:mail) {  
	            String email = ele.attr("href");
	              
	            System.out.println("����:"+email);  
		    }
		    for (Element ele:phonenumber){
		    	String phone = ele.attr("href");
		    	System.out.println("�绰��"+phone);
		    }
		    String text = doc.body().text(); 
		    System.out.println(text);
		    File file = new File("F:/eclipse/Test1");
		    FileOutputStream fs = new FileOutputStream(file);
		   
		} catch (IOException e) {
			
			// TODO �Զ����ɵ� catch 
			e.printStackTrace();
		}
		

	   
	}
	
	
}
